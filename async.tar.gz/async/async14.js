var async = require('async');

// some
async.some([1,2,3,6], function(item, callback){ 
    console.log('1.1 enter: ', item); 
    setTimeout(function(){ 
        console.log('1.1 handle: ', item); 
        callback(item<=3); 
    }, 5000);    
}, function(result) { 
    console.log('1.1 result: ', result); 
});
