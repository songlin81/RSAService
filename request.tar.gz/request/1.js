// $ npm install request

var request = require('request');

// http get
request('http://www.modulus.io', 
    function (error, response, body) {
        if (!error && response.statusCode == 200) {
            //console.log(body);
        }
});

// https get
request('https://modulus.io', 
    function (error, response, body) {
    if(error){
        return console.log('Error:', error);
    }
    if(response.statusCode !== 200){
        return console.log('Invalid Status Code Returned:', response.statusCode);
    }
    //console.log(body); 
});

// More Configurations
request({
    url: 'http://modulus.io',
    qs: {from: 'blog example', time: +new Date()},
    method: 'GET',
    headers: {
        'Content-Type': 'MyContentType',
        'Custom-Header': 'Custom Value'
    }
}, function(error, response, body){
    if(error) {
        console.log(error);
    } else {
        //console.log(response.statusCode, body);
    }
});

// Post qs
request({
    url: 'http://modulus.io',
    qs: {from: 'blog example', time: +new Date()},
    method: 'POST',
    headers: {
        'Content-Type': 'MyContentType',
        'Custom-Header': 'Custom Value'
    },
    body: 'Hello Hello! String body!'
}, function(error, response, body){
    if(error) {
        console.log(error);
    } else {
        //console.log(response.statusCode, body);
    }
});

// Post form
request({
    url: 'http://modulus.io', 
    qs: {from: 'blog example', time: +new Date()}, 
    method: 'POST',
    form: {
        field1: 'data',
        field2: 'data'
    }
}, function(error, response, body){
    if(error) {
        console.log(error);
    } else {
       // console.log(response.statusCode, body);
    }
});

// POST JSON
request({
    url: 'https://modulus.io',
    qs: {from: 'blog example', time: +new Date()},
    method: 'POST',
    json: {
        field1: 'data',
        field2: 'data'
    }
}, function(error, response, body){
    if(error) {
        console.log(error);
    } else {
        //console.log(response.statusCode, body);
}
});

//
var fs = require('fs');
//Lets define a write stream for our destination file
var destination = fs.createWriteStream('./savedImage.png');
//Lets save the modulus logo now
//request('https://my.modulus.io/img/modulus-logoSmall-gray20.png').pipe(destination);


//Lets save the modulus logo now
request('https://my.modulus.io/img/modulus-logoSmall-gray20.png')
.pipe(destination)
.on('error', function(error){
    console.log(error);
});


//
//Lets define a read stream from our source file, it could be any JSON file.
var source = fs.createReadStream('./sampleData.json');
//Let’s send our data via POST request
source.pipe(request.post('https://modulus.io/contact/demo'));

