var async = require('async');

// reject
async.reject([1,2,3,4,5], function(item, callback) { 
    console.log('1.4 enter: ' + item); 
    setTimeout(function() { 
        console.log('1.4 test: ' + item); 
        callback(item>=3); 
    }, 200); 
}, function(results) { 
    console.log('1.4 results: ', results); 
});