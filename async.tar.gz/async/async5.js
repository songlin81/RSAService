var async = require('async');

// auto
console.time("auto方法");

async.auto({  
   task1: function(callback){  
    console.log("task1");  
    setTimeout(function(){  
      callback(null, 'task11', 'task12');  
    },2000);  
   },

   task2: function(callback){   
    console.log('task2');  
    setTimeout(function(){         
      callback(null, 'task2');  
    },3000);  
   },

   task3: ['task1', 'task2', function(callback, results){  
    console.log('task3');  
    console.log('task1和task2运行结果: ',results);  
    setTimeout(function(){          
      callback(null, 'task3');  
    },1000);  
   }],  

   task4: ['task3', function(callback, results){  
    console.log('task4');  
    console.log('task1,task2,task3运行结果: ',results);  
    setTimeout(function(){  
        callback(null, {'task41':results.task3, 'task42':'task42'});  
     },1000);  
   }]  

}, function(err, results) {  

   console.log('err :', err);  
   console.log('最终results : ', results);  
   console.timeEnd("auto方法");  

});
