//npm install async
var async = require('async');


// 1. async series
var task1 =function(callback){  
    console.log("task1");  
    callback(null,"task1")  
}  
var task2 =function(callback){  
    console.log("task2");  
    callback(null,"task2")  
}  
var task3 =function(callback){  
    console.log("task3");  
    callback(null,"task3")  
}  
async.series([task1,task2,task3], function(err,result){  
    if (err) {  
        console.log("series: "+err+'\n');  
    }
    else{
        console.log("series: "+result+'\n');
    }
})


// 2. async series with exceptions.
var task1 =function(callback){  
    console.log("task1");  
    callback(null,"task1")  
}  
var task2 =function(callback){  
    console.log("task2");  
    callback("err", "task2")
}  
var task3 =function(callback){  
    console.log("task3");  
    callback(null,"task3")  
}  
async.series([task1,task2,task3], function(err, result){  
    if (err) {  
        console.log("series with exception: "+err);  
    }
    console.log("series with exception: "+result+'\n');
})


// 3. parallel
var task1 =function(callback){  
    console.log("task1");  
    setTimeout(function(){  
        callback(null,"task1")  
    },5000);  
}  
var task2 =function(callback){  
    console.log("task2");  
    setTimeout(function(){  
        callback(null,"task2")  
    },1000);  
}  
var task3 =function(callback){  
    console.log("task3");  
    setTimeout(function(){  
        callback(null,"task3")  
    },3000);  
}  
console.time("parallel方法:");
async.parallel([task1,task2,task3], function(err, result){  
    if (err) {  
        console.log("parallel: "+err+'\n');  
    }
    console.log("parallel: "+result+'\n');  
    console.timeEnd("parallel方法:");
})
