var async = require('async');

// parallel limit
var task1 =function(callback){  
    console.log("task1");  
    setTimeout(function(){  
        callback(null,"task1")  
    },5000);  
}
var task2 =function(callback){  
    console.log("task2");  
    setTimeout(function(){  
        callback(null,"task2")  
    },3000);  
}  
var task3 =function(callback){  
    console.log("task3");  
    setTimeout(function(){  
        callback(null,"task3")  
    },4000);  
}

console.time("parallelLimit方法");  
async.parallelLimit([task1,task2,task3], 2, function(err, result){  
    if (err) {
        console.log(err);  
    }  
    console.log(result);
    console.timeEnd("parallelLimit方法");  
})
