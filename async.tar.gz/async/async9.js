var async = require('async');

// filter
async.filter([1,2,3,4,5], function(item, callback) { 
    console.log('1.1 enter: ' + item); 
    setTimeout(function() { 
        console.log('1.1 test: ' + item); 
        callback(item>=3); 
    }, 200); 
}, function(results) { 
    console.log('1.1 results: ', results); 
});
