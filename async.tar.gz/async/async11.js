var async = require('async');

// reduce
var arr = [1,3,5];

async.reduce(arr, 100, function(memo, item, callback) { 
    console.log('1.1 enter: ' + memo +', ' + item); 
    setTimeout(function() { 
        callback(null, memo+item); 
    }, 100); 
},function(err, result) { 
    console.log('1.1 err: ', err); 
    console.log('1.1 result: ', result); 
});
