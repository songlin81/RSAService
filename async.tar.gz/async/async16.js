var async = require('async');

async.concat(
    ['aa','bb'], 
    function(item,callback) {
        //setTimeout(function() {
            callback(null, [item, item, item]);
       // }, 5000);
    }, 
    function(err, values) {
        console.log('1.1 err: ', err);
        console.log('1.1 values: ', values);
    }
);
