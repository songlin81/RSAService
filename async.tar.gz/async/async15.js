var async = require('async');

// every

var arr = [1,2,3,6];

async.every(arr, function(item, callback){ 
    console.log('1.1 enter: ', item); 
    setTimeout(function(){ 
        console.log('1.1 handle: ', item); 
        callback(item<=10); 
    }, 5000);    
}, function(result) { 
    console.log('1.1 result: ', result); 
});