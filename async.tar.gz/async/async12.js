var async = require('async');

// detect, retrieve the 1st element satifiying the condition.
var arr = [{value:1,delay:500}, 
           {value:2,delay:200}, 
           {value:3,delay:300}];

async.detect(arr, function(item, callback){ 
    console.log('1.1 enter: ', item.value); 
    setTimeout(function() {
        console.log('1.1 handle: ', item.value); 
        callback(item.value%2===1); 
    }, item.delay); 
}, function(result) { 
    console.log('1.1 result: ', result); 
});
