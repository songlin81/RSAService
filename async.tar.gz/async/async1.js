var async = require('async');

// parallel with exception
var task4 =function(callback){  
    console.log("task4");  
    setTimeout(function(){  
        callback(null,"task4")  
    },5000);  
}  
var task5 =function(callback){  
    console.log("task5");  
    setTimeout(function(){  
        callback("errmessage","task5")  
    },3000);  
}  
var task6 =function(callback){  
    console.log("task6");  
    setTimeout(function(){  
        callback(null,"task6")  
    },1000);  
}  
console.time("parallel方法");  
async.parallel([task4,task5,task6], function(err, result){  
    if (err) {  
        console.log(err+'\n');  
    }  
    console.log(result+'\n');  
    console.timeEnd("parallel方法");  
})