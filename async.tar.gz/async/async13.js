var async = require('async');

// sortBy
var arr = [3,6,1];

async.sortBy(arr, function(item, callback) { 
    setTimeout(function() { 
        callback(null,item); 
    }, 5000); 
}, function(err,results) { 
    console.log('1.1 err: ', err); 
    console.log('1.1 results: ', results); 
});
