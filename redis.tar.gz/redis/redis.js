//
// $ npm install redis
// $ redis-server
//
//  songlin81:~/workspace $ redis-cli ping
//  PONG
//  songlin81:~/workspace $ redis-cli
//  127.0.0.1:6379> ping
//  PONG
//  127.0.0.1:6379> set mykey somevalue
//  OK
//  127.0.0.1:6379> get mykey
//  "somevalue"


var redis = require('redis');
var client = redis.createClient();


//1
client.on('connect', function() {
    console.log('1...connected');
});


//2
client.set('framework', 'AngularJS', function(err, reply) {
  console.log('2a...'+reply);   //OK
});
client.get('framework', function(err, reply) {
    console.log('2b...'+reply); //AngularJS
});


//3
client.hmset('frameworks', {
    'javascript': 'AngularJS',
    'css': 'Bootstrap',
    'node': 'Express'
});
client.hgetall('frameworks', function(err, object) {
    console.log('3...');
    console.log(object);
});


//4
client.rpush(['frameworks2', 'angularjs', 'backbone'], function(err, reply) {
    console.log('4...'+reply); //prints 2
    console.log('4...'+err); //prints null
});
client.lrange('frameworks2', 0, -1, function(err, reply) {
    console.log('4...'+reply); // ['angularjs', 'backbone']
});


//5 Sets are similar to lists, but the difference is that they don’t allow duplicates. 
client.sadd(['tags', 'angularjs', 'backbonejs', 'emberjs'], function(err, reply) {
    console.log('5...'+reply); // 3
});
client.smembers('tags', function(err, reply) {
    console.log('5...'+reply);  //angularjs,backbonejs,emberjs
});


//6
client.del('frameworks2', function(err, reply) {
    console.log('6...'+reply);  //1
});


//7
client.exists('frameworks2', function(err, reply) {
    if (reply === 1) {
        console.log('7...'+'exists');
    } else {
        console.log('7...'+'doesn\'t exist'); //<---
    }
});


//8
client.set('key1', 'val1');
client.expire('key1', 30);


//9
client.set('key1', 10, function() {
    client.incr('key1', function(err, reply) {
        console.log('9...'+reply); // 11
    });
});
